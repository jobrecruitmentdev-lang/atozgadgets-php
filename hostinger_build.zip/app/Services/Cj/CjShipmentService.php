<?php

namespace App\Services\Cj;

class CjShipmentService
{
    // Legacy Node.js Service ported to Laravel
    public function __construct()
    {
    }
}

