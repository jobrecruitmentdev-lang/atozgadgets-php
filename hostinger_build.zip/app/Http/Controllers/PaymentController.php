<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Payment;
use App\Models\Order;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    /**
     * Handle Payoneer Payment Gateway
     */
    public function payWithPayoneer(Request $request)
    {
        // 1. Validate the cart / order
        $cart = session()->get('cart', []);
        if (empty($cart)) {
            return redirect()->route('store.cart')->with('error', 'Cart is empty');
        }

        $total = collect($cart)->sum(function($item) {
            return $item['price'] * $item['quantity'];
        });

        // 2. Mock Order Creation
        $order = Order::create([
            'user_id' => 1, // Mock user ID since we don't enforce auth everywhere yet
            'total_amount' => $total,
            'status' => 'pending'
        ]);

        // 3. Mock Payoneer API Call
        // In a real scenario, you'd use HTTP client to ping Payoneer Checkout API
        $mockPayoneerResponse = [
            'status' => 'success',
            'transaction_id' => 'PAYONEER-' . Str::upper(Str::random(12))
        ];

        // 4. Save to Payments Table (which now has Payoneer fields)
        Payment::create([
            'order_id' => $order->id,
            'amount' => $total,
            'payment_method' => 'payoneer',
            'payoneer_transaction_id' => $mockPayoneerResponse['transaction_id'],
            'status' => 'completed'
        ]);

        // 5. Update Order Status
        $order->update(['status' => 'processing']);

        // 6. Clear session cart
        session()->forget('cart');

        return redirect()->route('store.home')->with('success', "Order placed successfully! Paid via Payoneer (TxID: {$mockPayoneerResponse['transaction_id']}).");
    }
}
