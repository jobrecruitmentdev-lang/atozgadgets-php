<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;

class StorefrontController extends Controller
{
    public function home()
    {
        $categories = Category::where('status', 'active')->limit(4)->get();
        $featuredProducts = Product::where('is_active', true)
                                   ->where('is_featured', true)
                                   ->limit(8)
                                   ->get();
        
        return view('store.home', compact('categories', 'featuredProducts'));
    }

    public function shop(Request $request)
    {
        $query = Product::where('is_active', true);
        
        if ($request->has('category')) {
            $query->whereHas('category', function($q) use ($request) {
                $q->where('slug', $request->category);
            });
        }
        
        $products = $query->paginate(12);
        $categories = Category::where('status', 'active')->get();
        
        return view('store.shop', compact('products', 'categories'));
    }

    public function product($slug)
    {
        $product = Product::where('slug', $slug)->where('is_active', true)->firstOrFail();
        $relatedProducts = Product::where('category_id', $product->category_id)
                                  ->where('id', '!=', $product->id)
                                  ->limit(4)
                                  ->get();
                                  
        return view('store.product', compact('product', 'relatedProducts'));
    }
}
