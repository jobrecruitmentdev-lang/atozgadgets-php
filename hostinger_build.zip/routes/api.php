<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// ==========================================
// STOREFRONT APIs (Matches old Node.js routes)
// ==========================================
Route::prefix('auth')->group(function () {
    Route::post('login', [\App\Http\Controllers\Api\AuthController::class, 'login']);
    Route::post('register', [\App\Http\Controllers\Api\AuthController::class, 'register']);
});

Route::prefix('products')->group(function () {
    Route::get('/', [\App\Http\Controllers\Api\ProductController::class, 'index']);
    Route::get('/{slug}', [\App\Http\Controllers\Api\ProductController::class, 'show']);
});

Route::prefix('categories')->group(function () {
    Route::get('/', [\App\Http\Controllers\Api\CategoryController::class, 'index']);
});

// Protected Storefront Routes
Route::middleware('auth:sanctum')->group(function () {
    Route::get('auth/me', [\App\Http\Controllers\Api\AuthController::class, 'me']);
    
    Route::prefix('cart')->group(function () {
        Route::get('/', [\App\Http\Controllers\Api\CartController::class, 'index']);
        Route::post('/', [\App\Http\Controllers\Api\CartController::class, 'store']);
        Route::put('/{id}', [\App\Http\Controllers\Api\CartController::class, 'update']);
        Route::delete('/{id}', [\App\Http\Controllers\Api\CartController::class, 'destroy']);
    });

    Route::prefix('orders')->group(function () {
        Route::get('/', [\App\Http\Controllers\Api\OrderController::class, 'index']);
        Route::post('/', [\App\Http\Controllers\Api\OrderController::class, 'store']);
        Route::get('/{id}', [\App\Http\Controllers\Api\OrderController::class, 'show']);
    });
});

// ==========================================
// ADMIN APIs (Matches old Node.js internal APIs)
// ==========================================
Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
    Route::get('dashboard', [\App\Http\Controllers\Api\Admin\DashboardController::class, 'index']);
    
    // CJ Dropshipping Interop
    Route::prefix('cj')->group(function () {
        Route::get('search', [\App\Http\Controllers\Api\Admin\CJDropshippingController::class, 'search']);
        Route::post('import', [\App\Http\Controllers\Api\Admin\CJDropshippingController::class, 'import']);
        Route::post('sync', [\App\Http\Controllers\Api\Admin\CJDropshippingController::class, 'sync']);
    });

    // Core Management APIs
    Route::apiResource('inventory', \App\Http\Controllers\Api\InventoryController::class);
    Route::apiResource('media', \App\Http\Controllers\Api\MediaFileController::class);
    Route::apiResource('notifications', \App\Http\Controllers\Api\NotificationController::class);
    Route::apiResource('offers', \App\Http\Controllers\Api\OfferController::class);
    Route::apiResource('payments', \App\Http\Controllers\Api\PaymentController::class);
    Route::apiResource('returns', \App\Http\Controllers\Api\ReturnOrderController::class);
    Route::apiResource('shipments', \App\Http\Controllers\Api\ShipmentController::class);
    Route::apiResource('subcategories', \App\Http\Controllers\Api\SubcategoryController::class);
    Route::apiResource('user_sessions', \App\Http\Controllers\Api\UserSessionController::class);
});

// Protected User APIs
Route::middleware('auth:sanctum')->group(function () {
    Route::apiResource('wishlist', \App\Http\Controllers\Api\WishlistController::class)->only(['index', 'store', 'destroy']);
});
