@extends('layouts.auth')

@section('title', 'CJ Dropshipping Import - AtoZGadgets Admin')

@section('content')
<style>
    .admin-container { width: 100%; max-width: 1000px; padding: 30px; background: var(--glass-bg); backdrop-filter: blur(20px); border: 1px solid var(--glass-border); border-radius: 20px; box-shadow: 0 30px 60px rgba(0, 0, 0, 0.4); animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
    .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 1px solid var(--glass-border); padding-bottom: 20px; }
    .admin-header h1 { font-size: 26px; font-weight: 700; background: linear-gradient(135deg, #fff 0%, #a5b4fc 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .filters-grid { display: grid; grid-template-columns: repeat(3, 1fr) auto; gap: 15px; margin-bottom: 30px; }
    .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; max-height: 500px; overflow-y: auto; padding-right: 10px; }
    .product-grid::-webkit-scrollbar { width: 6px; }
    .product-grid::-webkit-scrollbar-track { background: rgba(255,255,255,0.05); border-radius: 10px; }
    .product-grid::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 10px; }
    .product-card { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 16px; transition: transform 0.3s, background 0.3s, box-shadow 0.3s; position: relative; overflow: hidden; }
    .product-card:hover { transform: translateY(-5px); background: rgba(255, 255, 255, 0.08); box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
    .product-img { width: 100%; height: 180px; object-fit: cover; border-radius: 12px; margin-bottom: 12px; background: rgba(0,0,0,0.2); }
    .product-title { font-size: 15px; font-weight: 600; margin-bottom: 8px; color: var(--text-primary); display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .product-price { font-size: 18px; font-weight: 700; color: #34d399; margin-bottom: 15px; }
    .btn-sm { padding: 8px 16px; font-size: 14px; border-radius: 8px; margin-top: 0; }
    .btn-outline { background: transparent; border: 1px solid var(--accent-color); color: var(--accent-color); }
    .badge { position: absolute; top: 25px; right: 25px; background: rgba(0,0,0,0.6); backdrop-filter: blur(4px); color: #fff; font-size: 11px; padding: 4px 8px; border-radius: 6px; font-weight: 600; }
    .loader { border: 4px solid rgba(255,255,255,0.1); border-top: 4px solid #fff; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 20px auto; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>

<div class="admin-container">
    <div class="admin-header">
        <h1>CJ Dropshipping Gateway</h1>
        <p>Real-time API Sync</p>
    </div>

    <div class="filters-grid">
        <div class="form-group" style="margin-bottom: 0;">
            <input type="text" class="form-input" placeholder="Search product keyword..." id="searchInput">
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <select class="form-input" style="appearance: none;" id="budgetFilter">
                <option value="">Any Budget</option>
                <option value="low">Low (< $10)</option>
                <option value="medium">Medium ($10 - $50)</option>
                <option value="high">High (> $50)</option>
            </select>
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <select class="form-input" style="appearance: none;" id="markupFilter">
                <option value="100">+100% Markup</option>
                <option value="50">+50% Markup</option>
                <option value="200">+200% Markup</option>
            </select>
        </div>
        <button class="btn-primary btn-sm" onclick="fetchProducts()" style="height: 100%;">Search API</button>
    </div>

    <div class="product-grid" id="productGrid">
        <p style="color:var(--text-secondary); grid-column: 1 / -1; text-align: center; margin-top: 40px;">Enter a keyword above and click Search API.</p>
    </div>
</div>

<script>
    async function fetchProducts() {
        const btn = document.querySelector('button[onclick="fetchProducts()"]');
        const grid = document.getElementById('productGrid');
        const keyword = document.getElementById('searchInput').value || 'smart';
        
        btn.innerText = 'Searching...';
        btn.disabled = true;
        grid.innerHTML = '<div style="grid-column: 1 / -1;"><div class="loader"></div></div>';
        
        try {
            const response = await fetch(`/admin/api/catalog/search?keyword=${encodeURIComponent(keyword)}`);
            const data = await response.json();
            
            grid.innerHTML = '';
            
            if(data.data && data.data.list && data.data.list.length > 0) {
                data.data.list.forEach(item => {
                    const price = parseFloat(item.sellPrice).toFixed(2);
                    grid.innerHTML += `
                        <div class="product-card">
                            <span class="badge">${item.categoryName || 'General'}</span>
                            <img src="${item.productImage}" alt="" class="product-img">
                            <div class="product-title">${item.productNameEn}</div>
                            <div class="product-price">$${price}</div>
                            <button class="btn-primary btn-sm w-100" 
                                onclick="importProduct(this, '${item.pid}', '${item.productNameEn.replace(/'/g, "\\'")}', ${price}, '${item.productImage}', '${item.categoryName || ''}')">
                                Import to Local DB
                            </button>
                        </div>
                    `;
                });
            } else {
                grid.innerHTML = '<p style="color:var(--text-secondary); grid-column: 1 / -1; text-align: center;">No products found.</p>';
            }
        } catch(e) {
            console.error(e);
            grid.innerHTML = '<p style="color:red; grid-column: 1 / -1; text-align: center;">Error fetching API data.</p>';
        }
        
        btn.innerText = 'Search API';
        btn.disabled = false;
    }

    async function importProduct(btn, pid, title, price, image, category) {
        btn.innerText = 'Importing...';
        btn.style.opacity = '0.7';
        btn.disabled = true;
        
        try {
            const res = await fetch('/admin/api/catalog/import-item', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ pid, title, price, image, category })
            });
            
            const result = await res.json();
            
            if(result.success) {
                btn.innerText = '✓ Imported';
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-outline');
                btn.style.opacity = '1';
                btn.parentElement.style.boxShadow = '0 0 20px rgba(52, 211, 153, 0.4)';
            } else {
                throw new Error('Failed');
            }
        } catch(e) {
            btn.innerText = 'Error';
            btn.style.background = 'red';
        }
    }
</script>
@endsection
