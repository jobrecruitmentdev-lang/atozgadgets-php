@extends('layouts.admin')

@section('title', 'Admin Dashboard Overview')

@section('content')
<style>
    .page-title { font-size: 24px; font-weight: 700; margin-bottom: 24px; }
    
    .stats-grid { display: grid; grid-template-columns: repeat(1, 1fr); gap: 24px; margin-bottom: 32px; }
    @media (min-width: 768px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (min-width: 1024px) { .stats-grid { grid-template-columns: repeat(4, 1fr); } }
    
    .stat-card { padding: 24px; display: flex; flex-direction: column; }
    .stat-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; }
    .stat-title { font-size: 14px; font-weight: 500; color: var(--text-secondary); margin-bottom: 4px; }
    .stat-value { font-size: 30px; font-weight: 700; }
    .stat-icon-wrap { padding: 8px; background: rgba(128,128,128,0.1); border-radius: 8px; }
    
    .trend { display: flex; align-items: center; font-size: 14px; }
    .trend-up { color: #10b981; font-weight: 500; }
    .trend-down { color: #ef4444; font-weight: 500; }
    .trend-text { color: var(--text-secondary); margin-left: 8px; }

    .chart-placeholder { height: 400px; display: flex; align-items: center; justify-content: center; font-size: 14px; color: var(--text-secondary); }
</style>

<h1 class="page-title">Dashboard Overview</h1>

<div class="stats-grid">
    <div class="card stat-card">
        <div class="stat-header">
            <div>
                <p class="stat-title">Total Revenue</p>
                <h3 class="stat-value">$12,450.00</h3>
            </div>
            <div class="stat-icon-wrap"><i data-lucide="dollar-sign" style="color:var(--text-secondary);"></i></div>
        </div>
        <div class="trend">
            <i data-lucide="arrow-up-right" class="trend-up" style="width:16px;"></i>
            <span class="trend-up">+20.1%</span>
            <span class="trend-text">vs last month</span>
        </div>
    </div>

    <div class="card stat-card">
        <div class="stat-header">
            <div>
                <p class="stat-title">Orders</p>
                <h3 class="stat-value">156</h3>
            </div>
            <div class="stat-icon-wrap"><i data-lucide="shopping-cart" style="color:var(--text-secondary);"></i></div>
        </div>
        <div class="trend">
            <i data-lucide="arrow-up-right" class="trend-up" style="width:16px;"></i>
            <span class="trend-up">+12.5%</span>
            <span class="trend-text">vs last month</span>
        </div>
    </div>

    <div class="card stat-card">
        <div class="stat-header">
            <div>
                <p class="stat-title">Active Customers</p>
                <h3 class="stat-value">2,341</h3>
            </div>
            <div class="stat-icon-wrap"><i data-lucide="users" style="color:var(--text-secondary);"></i></div>
        </div>
        <div class="trend">
            <i data-lucide="arrow-up-right" class="trend-up" style="width:16px;"></i>
            <span class="trend-up">+5.4%</span>
            <span class="trend-text">vs last month</span>
        </div>
    </div>

    <div class="card stat-card">
        <div class="stat-header">
            <div>
                <p class="stat-title">Products in Stock</p>
                <h3 class="stat-value">14,204</h3>
            </div>
            <div class="stat-icon-wrap"><i data-lucide="package" style="color:var(--text-secondary);"></i></div>
        </div>
        <div class="trend">
            <i data-lucide="arrow-down-right" class="trend-down" style="width:16px;"></i>
            <span class="trend-down">-1.2%</span>
            <span class="trend-text">vs last month</span>
        </div>
    </div>
</div>

<div class="card chart-placeholder">
    Sales Chart Placeholder
</div>

@endsection
